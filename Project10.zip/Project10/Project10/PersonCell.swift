//
//  PersonCell.swift
//  Project10
//
//  Created by Vladimir on 21.12.2024.
//

import UIKit

class PersonCell: UICollectionViewCell {
    @IBOutlet var imageView: UIImageView!
    @IBOutlet var name: UILabel!
}
